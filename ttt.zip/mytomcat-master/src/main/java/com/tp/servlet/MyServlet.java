package com.tp.servlet;

import com.tp.request.HttpServletRequest;
import com.tp.response.HttpServletResponse;
import com.tp.servlet.abs.Servlet;

/**
 * @program: mdemo
 * @description: 自定义Servlet
 * @author: Xin Wu
 * @create: 2019-07-07 19:57
 **/
public class MyServlet extends Servlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        response.write("<h1>真开心！！！！</h1>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) {

    }
}
